$(document).ready(function () {
  
  // Fetch all the forms we want to apply custom Bootstrap validation styles to
        var lookups = document.getElementsByClassName('postcode-lookup');
        var uselookup = document.getElementsByClassName('use-lookup');
        var usemanual = document.getElementsByClassName('use-manual');

        // Loop over them and prevent submission
        var addresslookup = Array.prototype.filter.call(lookups, function(lookup) {
          lookup.addEventListener('click', function(event) {

            event.preventDefault();
            event.stopPropagation();

            var target = $(this).attr('href');

            /* If 1 address found */
            if($(this).is('[data-example]') && $(this).attr('data-example') == "found"){

              $(target).addClass('target');
            }
            /* If more than one address found */
            else if($(this).is('[data-example]') && $(this).attr('data-example') == "multi"){

              var choices = $(this).attr('data-choices-id');

              $(choices).addClass('target');
              $(target).addClass('target');
            }
            /* If more than one address found */
            else if($(this).is('[data-example]') && $(this).attr('data-example') == "error"){

              console.log('error');
              var $btn = $(this);

              var $formgroup = $(this).closest(".form-group");
              $formgroup.addClass("form-group-error");

              $('.invalid-feedback[data-for="'+$btn.attr('id')+'"').remove();
              $btn.before('<span class="invalid-feedback" data-for="'+$btn.attr('id')+'">'+$btn.attr('data-error')+'</span>');

            }
            /* If no address found */
            else {

            }
          }, false);
        });

        // Loop over them and prevent submission
        var uselookupfunc = Array.prototype.filter.call(uselookup, function(uselookup) {
          uselookup.addEventListener('click', function(event) {


              event.preventDefault();
              event.stopPropagation();

              var target = $(this).attr('data-address-id');
              $(target).removeClass('target');

              var choices = $(this).attr('data-choices-id');
              $(choices).removeClass('target');

          }, false);
        });
        // Loop over them and prevent submission
        var usemanualfunc = Array.prototype.filter.call(usemanual, function(usemanual) {
          usemanual.addEventListener('click', function(event) {

              event.preventDefault();
              event.stopPropagation();

              var target = $(this).attr('href');
              $(target).addClass('target');

          }, false);
        });
  
});