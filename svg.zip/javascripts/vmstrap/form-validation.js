$(document).ready(function () {

  $('form').on('submit',function(event){
    
    $form = $(this);
    
    /* Reset */
    $form.find('.form-group-error').removeClass('form-group-error');
    $form.find('.input-validation-error').closest('.form-group').addClass('form-group-error');
    $form.find('.field-validation-error').addClass('invalid-feedback');
    $form.find('.alert-danger').remove();
    
    // If errors display the summary
    // Make the validation error messaging work with the GDS/bootstrap/phoenix styling
    if($form.find('.form-group-error').length){
      $form.prepend('<div class="alert alert-danger" role="alert">\
        <div class="svg__wrapper">\
            <svg><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="/public/svg/general.svg#attention"></use></svg>\
        </div>\
        <span class="display-5">There are errors on this page</span>\
      </div>');

      $form.find('.form-group-error').each(function(index){

        label = $(this).find('label').attr('data-error-label');

        if(label != undefined)
          $form.find('.alert-danger').append('<span>'+label+'</span>');
      });
    }
  });
  
  // Make the inline validation worh with GDS/bootstrap/phoenix styling
  $('.form-control').on('keyup focusin focusout',function(event){
    // Set a small timeout so that it runs after the validation has been done
    
    $input = $(this);
    
    setTimeout(function(){
    
      // Reset
      $input.removeClass('invalid-feedback');
      $input.closest('.form-group').removeClass('form-group-error');
      
      // Add the right classes
      $('.field-validation-error').addClass('invalid-feedback');
      $('.input-validation-error').closest('.form-group').addClass('form-group-error');
    }, 100);
  });
});