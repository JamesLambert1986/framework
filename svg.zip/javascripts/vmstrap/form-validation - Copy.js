(function() {
      'use strict';
      window.addEventListener('load', function() {

        // Fetch all the forms we want to apply custom Bootstrap validation styles to
        var forms = document.querySelectorAll('.needs-validation');
        // Loop over them and prevent submission
        var validation = Array.prototype.filter.call(forms, function(form) {
          form.addEventListener('submit', function(event) {
            if (form.checkValidity() === false) {
              event.preventDefault();
              event.stopPropagation();

              /* Sorry about the jquery Will - We can talk about changing it when your back etc */
              /* Add the error class to the wrapper div so we can style things better */
              $(form).find('.form-group-error').removeClass('form-group-error');
              $(form).find("input:invalid").each(function(index){
                var $formgroup = $(this).closest(".form-group");
                $formgroup.addClass("form-group-error");
                $formgroup.find('label[data-invalid-feedback]').append("<span class='invalid-feedback'>"+$formgroup.find('label[data-invalid-feedback]').attr('data-invalid-feedback')+"</span>");
                $formgroup.find('label[data-invalid-feedback]').removeAttr('data-invalid-feedback');
              });

              /* Confirm Password */
              $(form).find(".form-group--password.confirm input").each(function(index){

                var matches = $(this).attr('data-match');
                var value = $(this).val();
                var $formgroup = $(this).closest(".form-group");

                if($("#"+matches).val() != value){

                  $formgroup.addClass("form-group-error");
                  $formgroup.find('label[data-invalid-feedback]').append("<span class='invalid-feedback'>"+$formgroup.find('label[data-invalid-feedback]').attr('data-invalid-feedback')+"</span>");
                  $formgroup.find('label[data-invalid-feedback]').removeAttr('data-invalid-feedback');
                }

              });
              
              
              /* Check to see what error messages need to display */
              
              
              form.scrollIntoView(true);
              
              function createElementFromHTML(htmlString) {
                var div = document.createElement('div');
                div.innerHTML = htmlString.trim();

                // Change this to div.childNodes to support multiple top-level nodes
                return div.firstChild; 
              }

              var el = createElementFromHTML('<div class="alert alert-danger" role="alert">\
                <div class="svg__wrapper">\
                    <svg><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="/public/svg/general.svg#attention"></use></svg>\
                </div>\
                <span class="display-5">There are errors on this page</span>\
                <span class="small">Business Trading name</span>\
              </div>');
              
              form.insertBefore(el, form.firstChild);
            }
            //form.classList.add('was-validated'); Remove this so that bootstraps validation classes dont get added
          }, false);
        });


        // Fetch all the forms we want to apply custom Bootstrap validation styles to
        var lookups = document.getElementsByClassName('postcode-lookup');
        var uselookup = document.getElementsByClassName('use-lookup');
        var usemanual = document.getElementsByClassName('use-manual');

        // Loop over them and prevent submission
        var addresslookup = Array.prototype.filter.call(lookups, function(lookup) {
          lookup.addEventListener('click', function(event) {

            event.preventDefault();
            event.stopPropagation();

            var target = $(this).attr('href');

            /* If 1 address found */
            if($(this).is('[data-example]') && $(this).attr('data-example') == "found"){

              $(target).addClass('target');
            }
            /* If more than one address found */
            else if($(this).is('[data-example]') && $(this).attr('data-example') == "multi"){

              var choices = $(this).attr('data-choices-id');

              $(choices).addClass('target');
              $(target).addClass('target');
            }
            /* If more than one address found */
            else if($(this).is('[data-example]') && $(this).attr('data-example') == "error"){

              console.log('error');
              var $btn = $(this);

              var $formgroup = $(this).closest(".form-group");
              $formgroup.addClass("form-group-error");

              $('.invalid-feedback[data-for="'+$btn.attr('id')+'"').remove();
              $btn.before('<span class="invalid-feedback" data-for="'+$btn.attr('id')+'">'+$btn.attr('data-error')+'</span>');

            }
            /* If no address found */
            else {

            }
          }, false);
        });

        // Loop over them and prevent submission
        var uselookupfunc = Array.prototype.filter.call(uselookup, function(uselookup) {
          uselookup.addEventListener('click', function(event) {


              event.preventDefault();
              event.stopPropagation();

              var target = $(this).attr('data-address-id');
              $(target).removeClass('target');

              var choices = $(this).attr('data-choices-id');
              $(choices).removeClass('target');

          }, false);
        });
        // Loop over them and prevent submission
        var usemanualfunc = Array.prototype.filter.call(usemanual, function(usemanual) {
          usemanual.addEventListener('click', function(event) {

              event.preventDefault();
              event.stopPropagation();

              var target = $(this).attr('href');
              $(target).addClass('target');

          }, false);
        });

        // btn expand
        var btnexpand = document.querySelectorAll('.btn--expand');
        var btnexpandfunc = Array.prototype.filter.call(btnexpand, function(btnexpand) {
          btnexpand.addEventListener('click', function(event) {

              event.preventDefault();
              event.stopPropagation();

              var target = $(this).attr('href');
              var $target = $(target);
              var $btn = $(this);

              if($target.hasClass('target')){

                $btn.removeClass('active');
                $target.removeClass('target');
              }
              else {

                $btn.addClass('active');
                $target.addClass('target');
              }

          }, false);
        });

      }, false);
    })();